from django import forms

class ContactForm(forms.Form):
	name = forms.CharField()
	email = forms.EmailField(label = 'Email-id')
	category = forms.ChoiceField(choices=[('Question', 'Question'), ('other', 'other')])
	subject = forms.CharField(required = False)
	body = forms.CharField(widget=forms.Textarea)